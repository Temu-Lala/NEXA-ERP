package maintenance_worelation

import (
	_ "nexa/addons/base"
	_ "nexa_addons/maintenance"
	_ "nexa_addons/maintenance_worelation/models"
)
