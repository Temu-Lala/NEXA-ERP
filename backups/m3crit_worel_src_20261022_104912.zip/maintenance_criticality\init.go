package maintenance_criticality

import (
	_ "nexa/addons/base"
	_ "nexa_addons/maintenance"
	_ "nexa_addons/maintenance_criticality/models"
)
