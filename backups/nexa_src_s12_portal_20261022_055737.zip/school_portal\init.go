package school_portal

import (
	_ "nexa/addons/base"
	_ "nexa_addons/school"
	_ "nexa_addons/school_guardians"
	_ "nexa_addons/school_portal/models"
	_ "nexa_addons/school_staff"
)
