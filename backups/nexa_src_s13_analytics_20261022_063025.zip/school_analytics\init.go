package school_analytics

import (
	_ "nexa/addons/base"
	_ "nexa_addons/school"
	_ "nexa_addons/school_analytics/models"
	_ "nexa_addons/school_setup"
)
