package school_governance

import (
	_ "nexa/addons/base"
	_ "nexa_addons/school"
	_ "nexa_addons/school_governance/models"
	_ "nexa_addons/school_setup"
)
