package maintenance_knowledge

import (
	_ "nexa/addons/base"
	_ "nexa_addons/maintenance"
	_ "nexa_addons/maintenance_equipment"
	_ "nexa_addons/maintenance_knowledge/models"
)
