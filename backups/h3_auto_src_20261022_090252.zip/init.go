package helpdesk_auto

import (
	_ "nexa/addons/base"
	_ "nexa_addons/helpdesk"
	_ "nexa_addons/helpdesk_auto/models"
)
