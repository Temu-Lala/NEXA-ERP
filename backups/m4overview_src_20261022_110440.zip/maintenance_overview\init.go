package maintenance_overview

import (
	_ "nexa/addons/base"
	_ "nexa_addons/maintenance"
	_ "nexa_addons/maintenance_criticality"
	_ "nexa_addons/maintenance_downtime"
	_ "nexa_addons/maintenance_equipment"
)
