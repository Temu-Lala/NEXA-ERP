package helpdesk_catalog

import (
	_ "nexa/addons/base"
	_ "nexa_addons/helpdesk"
	_ "nexa_addons/helpdesk_catalog/models"
)
