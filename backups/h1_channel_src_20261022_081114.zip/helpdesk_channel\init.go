package helpdesk_channel

import (
	_ "nexa/addons/base"
	_ "nexa_addons/helpdesk"
	_ "nexa_addons/helpdesk_channel/models"
)
